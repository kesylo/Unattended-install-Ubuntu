
function configure_kickstart() {
  local dest=$1
  cp -a kickstart/* $dest
}

function ubuntu_release() {
  rel=http://releases.ubuntu.com/$1
  echo $rel/$(curl --silent $rel/MD5SUMS | \grep -o 'ubuntu-.*-desktop-amd64.iso')
}

function get_iso_url() {
  # Overrides iso_url global variables

  # Get ISO
  # - read Ubuntu release from the official repo
  all=($(wget -O- releases.ubuntu.com -q | perl -ne '/Ubuntu (\d+.\d+)/ && print "$1\n"' | sort -Vu))
  # - if 'latest' gets the last release
  if [ "$1" == latest ]; then
    iso_url=$(ubuntu_release ${all[-1]})
  # - if empty, ask to the user
  elif [ -z "$*" ]; then
    echo "--> Please Choose the version of Ubuntu you want: " ${all[*]}
    read -p "--> Choice: " -e -i "${all[-1]}" v
    [ "$v" ] || v=${all[-1]}
    echo $v
    iso_url=$(ubuntu_release $v)
  # - if an HTTP URL is given take it as the ISO URL
  elif expr match "${1}" "^http" > /dev/null; then
    iso_url="$1"
  # - if numeric release is given, try it against official repo
  elif expr match "$1" "[0-9]\+.[0-9]\+$" > /dev/null; then
    iso_url=$(ubuntu_release $1)
  else
    usage
  fi
}

# vim: expandtab shiftwidth=2 tabstop=2
