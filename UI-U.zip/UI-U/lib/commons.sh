# Check for admin rights
function check_privileges() {
  if [ $(id -u) -ne 0 ]; then
    echo " You need root access to run this file."
    exit 1
  fi
}

# Banner
function banner() {
  local text=$1
  echo
  echo " +----------------------------------+"
  echo -n "         "
  echo "$text" | tr '[a-z]' '[A-Z]'
  echo " +----------------------------------+"
  echo
  echo " note: Make sure to run this script on 'debian' based system "
  echo
}

function download_ubuntu() {
  cd /tmp/
  if [ -f ubuntu-16.04.3-desktop-i386.iso ]; then
    echo "iso exists"
    iso="/tmp/ubuntu-16.04.3-desktop-i386.iso"
  else
    echo "downloading Ubuntu 16.04"
    wget http://ftp.releases.ubuntu.com/16.04/ubuntu-16.04.3-desktop-i386.iso -q --show-progress
    iso="/tmp/ubuntu-16.04.3-desktop-i386.iso"
  fi
  export iso
}

function usage() {
  echo "Usage: $0 <URL|...>"
  exit 1
}

# vim: expandtab shiftwidth=2 tabstop=2
