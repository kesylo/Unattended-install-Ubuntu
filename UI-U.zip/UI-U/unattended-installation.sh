#!/bin/bash

source lib/commons.sh
source functions.sh

check_privileges

banner "Famoco Unattented install"

ubuntu-server-auto-install()
{
  # Get ISO
  iso_url=""   # global variable, written by get_iso_url
  get_iso_url $1

  # - download ISO to local directory if not in the Downloads directory
  iso_base=$(basename $iso_url)
  iso=$(find ~/Downloads/ -name "$iso_base")
  if [ ! -e "$iso" ]; then
    wget -nc $iso_url -P ~/Downloads || return
    iso=~/Downloads/$iso_base
  fi
  echo ISO ready to use

  # ISO customization
  # - mount the ISO
  mnt=$(mktemp -d mount.CXXX)
  sudo mount $iso $mnt -o user,ro
  echo ISO mounted

  # - copy ISO content to workdir
  base=$(basename $iso .iso)
  auto=${base}-auto-install
  if [ ! -e $auto ]; then
    cp -a $mnt $auto
    chmod -R +w $auto
  fi
  echo ISO data copied

  # - umount ISO
  #sudo umount -f $mnt

  # - add kickstart
  configure_kickstart $auto
  echo ISO data customized

  # - rebuild the ISO
  mkisofs -U -allow-lowercase -q -input-charset iso8859-1 -A "ubuntu" \
    -V "ubuntu" -volset "ubuntu" -J -joliet-long -r -v -T -o $auto.iso \
    -b isolinux/isolinux.bin -c isolinux/boot.cat -no-emul-boot \
    -boot-load-size 4 -boot-info-table -eltorito-alt-boot \
    -e boot/grub/efi.img -no-emul-boot $auto

  isohybrid --uefi $auto.iso

  # - cleanup env
  sudo umount -l -f /dev/loop0
  sudo umount -l -f $mnt
  sudo rm -rf $mnt 
  sudo rm -rf $auto

  
  echo
  echo $auto.iso created
  echo "You can copy it using etcher or dd to your USB key"
  echo
}

# Main
ubuntu-server-auto-install "$@"

# vim: expandtab shiftwidth=2 tabstop=2
